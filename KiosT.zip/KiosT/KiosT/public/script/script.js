document.getElementById("search-input").addEventListener("input", function () {
  var input = this.value.toLowerCase();
  var cards = document.getElementsByClassName("card-game");

  for (var i = 0; i < cards.length; i++) {
    var cardText = cards[i].getElementsByTagName("p")[0].innerText.toLowerCase();
    if (cardText.includes(input)) {
      cards[i].style.display = "";
    } else {
      cards[i].style.display = "none";
    }
  }
});
